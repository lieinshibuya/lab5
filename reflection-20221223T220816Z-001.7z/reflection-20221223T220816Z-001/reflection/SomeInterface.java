package reflection;

/**
 * Interface class
 */
public interface SomeInterface {

    /**
     * A method that will be override in other classes.
     */
    void doSome();
}
