package reflection;

/**
 * Interface class
 */
public interface SomeOtherInterface {

    /**
     * A method that will be override in other classes.
     */
    void doSome();
}
